ActionController::PerformanceTest = ActionDispatch::PerformanceTest
