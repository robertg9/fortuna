module ActionController #:nodoc:
  module SessionManagement #:nodoc:
    extend ActiveSupport::Concern

    module ClassMethods

    end
  end
end
